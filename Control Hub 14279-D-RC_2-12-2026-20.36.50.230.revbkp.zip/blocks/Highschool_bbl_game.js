// IDENTIFIERS_USED=gamepad1,gamepad2,left_back_motorAsDcMotor,left_clawAsServo,left_front_motorAsDcMotor,lift_motorAsDcMotor,right_back_motorAsDcMotor,right_clawAsServo,right_front_motorAsDcMotor,turntbl_motorAsDcMotor

var movement_scalar;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  movement_scalar = 0.5;
  left_clawAsServo.setDirection("REVERSE");
  lift_motorAsDcMotor.setZeroPowerBehavior("BRAKE");
  turntbl_motorAsDcMotor.setDirection("REVERSE");
  right_front_motorAsDcMotor.setDirection("REVERSE");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    left_clawAsServo.setPosition(0);
    right_clawAsServo.setPosition(0);
    while (linearOpMode.opModeIsActive()) {
      if (gamepad2.getA()) {
        left_clawAsServo.setPosition(0.1);
        right_clawAsServo.setPosition(0.1);
      }
      if (gamepad2.getB()) {
        right_clawAsServo.setPosition(0);
        left_clawAsServo.setPosition(0);
      }
      left_back_motorAsDcMotor.setDualPower(movement_scalar * gamepad1.getLeftStickY(), left_front_motorAsDcMotor, movement_scalar * gamepad1.getLeftStickY());
      right_back_motorAsDcMotor.setDualPower(movement_scalar * gamepad1.getLeftStickY(), right_front_motorAsDcMotor, movement_scalar * gamepad1.getLeftStickY());
      left_back_motorAsDcMotor.setDualPower(movement_scalar * -gamepad1.getRightStickX(), left_front_motorAsDcMotor, movement_scalar * -gamepad1.getRightStickX());
      right_back_motorAsDcMotor.setDualPower(movement_scalar * gamepad1.getRightStickX(), right_front_motorAsDcMotor, movement_scalar * gamepad1.getRightStickX());
      left_back_motorAsDcMotor.setDualPower(movement_scalar * gamepad1.getLeftStickX(), left_front_motorAsDcMotor, movement_scalar * -gamepad1.getLeftStickX());
      right_back_motorAsDcMotor.setDualPower(movement_scalar * -gamepad1.getLeftStickX(), right_front_motorAsDcMotor, movement_scalar * gamepad1.getLeftStickX());
      lift_motorAsDcMotor.setPower(0.45 * gamepad2.getLeftStickY());
      turntbl_motorAsDcMotor.setPower(0.25 * gamepad2.getRightStickX());
      telemetry.update();
    }
  }
}
