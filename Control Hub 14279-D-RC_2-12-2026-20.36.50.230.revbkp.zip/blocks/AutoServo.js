// IDENTIFIERS_USED=servo1AsServo

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  linearOpMode.waitForStart();
  servo1AsServo.setPosition(0);
  linearOpMode.sleep(2000);
  servo1AsServo.setPosition(0.49999);
  linearOpMode.sleep(2000);
  servo1AsServo.setPosition(1);
  linearOpMode.sleep(2000);
}
