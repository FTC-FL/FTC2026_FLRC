// IDENTIFIERS_USED=motor1AsDcMotor

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  motor1AsDcMotor.setDirection("REVERSE");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    motor1AsDcMotor.setPower(1);
    linearOpMode.sleep(2000);
    motor1AsDcMotor.setPower(0);
    linearOpMode.sleep(1000);
    motor1AsDcMotor.setPower(-1);
    linearOpMode.sleep(2000);
    motor1AsDcMotor.setPower(0);
  }
}
