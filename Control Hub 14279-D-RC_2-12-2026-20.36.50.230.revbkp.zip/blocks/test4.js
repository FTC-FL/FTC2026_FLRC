// IDENTIFIERS_USED=gamepad1,motor1AsDcMotor

var mototarget, motoPos, target;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  motor1AsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  mototarget = 0;
  linearOpMode.waitForStart();
  drive(-gamepad1.getRightStickY() * 200);
}

/**
 * Describe this function...
 */
function drive(mototarget) {
  motoPos = (typeof motoPos == 'number' ? motoPos : 0) + target;
  motor1AsDcMotor.setTargetPosition(mototarget);
  motor1AsDcMotor.setMode("RUN_TO_POSITION");
  while (linearOpMode.opModeIsActive() && motor1AsDcMotor.isBusy()) {
    linearOpMode.idle();
  }
}
