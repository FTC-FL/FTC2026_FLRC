// IDENTIFIERS_USED=dist1AsDistanceSensor,dist2AsDistanceSensor

var my_2mdist_1, my_2mdist_2, Avg_dist;

/**
 * This function is executed when this OpMode is selected from the Driver Station.
 */
function runOpMode() {
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      my_2mdist_1 = dist1AsDistanceSensor.getDistance("MM");
      my_2mdist_2 = dist2AsDistanceSensor.getDistance("MM");
      Avg_dist = (my_2mdist_1 + my_2mdist_2) / 2;
      telemetry.addTextData('2m dist 1', String(my_2mdist_1));
      telemetry.addTextData('2m dist 2', String(my_2mdist_2));
      telemetry.addTextData('avg dist', String(Avg_dist));
      telemetry.update();
    }
  }
}
