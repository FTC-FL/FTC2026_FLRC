// IDENTIFIERS_USED=gamepad1,servo1AsServo

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  linearOpMode.waitForStart();
  servo1AsServo.setPosition(0);
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      if (gamepad1.getA()) {
        servo1AsServo.setPosition(1);
      }
      if (gamepad1.getB()) {
        servo1AsServo.setPosition(0);
      }
      telemetry.update();
    }
  }
}
