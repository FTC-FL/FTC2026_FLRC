// IDENTIFIERS_USED=gamepad1,intakebottomAsDcMotor,intaketopAsDcMotor

/**
 * This function is executed when this OpMode is selected from the Driver Station.
 */
function runOpMode() {
  linearOpMode.waitForStart();
  intakebottomAsDcMotor.setDirection("REVERSE");
  intaketopAsDcMotor.setDirection("REVERSE");
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      intakebottomAsDcMotor.setPower(gamepad1.getRightTrigger() * 1);
      intakebottomAsDcMotor.setPower(gamepad1.getLeftTrigger() * -1);
      telemetry.update();
    }
  }
}
