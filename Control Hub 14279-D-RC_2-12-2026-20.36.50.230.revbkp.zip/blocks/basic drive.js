// IDENTIFIERS_USED=gamepad1,left_motor_backAsDcMotor,left_motor_frontAsDcMotor,right_motor_backAsDcMotor,right_motor_frontAsDcMotor

var movement_scalar;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    movement_scalar = 0.75;
    while (linearOpMode.opModeIsActive()) {
      left_motor_frontAsDcMotor.setDualPower(gamepad1.getLeftStickY() * movement_scalar, right_motor_frontAsDcMotor, -(gamepad1.getLeftStickY() * movement_scalar));
      left_motor_backAsDcMotor.setDualPower(gamepad1.getLeftStickY() * movement_scalar, right_motor_backAsDcMotor, -(gamepad1.getLeftStickY() * movement_scalar));
      left_motor_frontAsDcMotor.setDualPower(-(gamepad1.getLeftStickX() * movement_scalar), left_motor_backAsDcMotor, gamepad1.getLeftStickX() * movement_scalar);
      right_motor_frontAsDcMotor.setDualPower(-(gamepad1.getLeftStickX() * movement_scalar), right_motor_backAsDcMotor, gamepad1.getLeftStickX() * movement_scalar);
      right_motor_frontAsDcMotor.setDualPower(gamepad1.getRightStickX() * movement_scalar, right_motor_backAsDcMotor, gamepad1.getRightStickX() * movement_scalar);
      left_motor_frontAsDcMotor.setDualPower(gamepad1.getRightStickX() * movement_scalar, left_motor_backAsDcMotor, gamepad1.getRightStickX() * movement_scalar);
      telemetry.update();
    }
  }
}
