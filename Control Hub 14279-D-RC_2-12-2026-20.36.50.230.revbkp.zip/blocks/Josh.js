// IDENTIFIERS_USED=gamepad1,leftLiftAsDcMotor,rightLiftAsDcMotor

/**
 * This sample contains the bare minimum Blocks for any regular OpMode. The 3 blue
 * Comment Blocks show where to place Initialization code (runs once, after touching the
 * DS INIT button, and before touching the DS
 * Start arrow), Run code (runs once, after
 * touching Start), and Loop code (runs repeatedly
 * while the OpMode is active, namely not
 * Stopped).
 */
function runOpMode() {
  leftLiftAsDcMotor.setDirection("REVERSE");
  leftLiftAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  rightLiftAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      if (gamepad1.getDpadUp()) {
        leftLiftAsDcMotor.setTargetPosition(1500);
        rightLiftAsDcMotor.setTargetPosition(1500);
        leftLiftAsDcMotor.setMode("RUN_TO_POSITION");
        rightLiftAsDcMotor.setMode("RUN_TO_POSITION");
        leftLiftAsDcMotor.setPower(0.65);
        rightLiftAsDcMotor.setPower(0.65);
      }
      if (gamepad1.getDpadDown()) {
        leftLiftAsDcMotor.setTargetPosition(10);
        rightLiftAsDcMotor.setTargetPosition(10);
        leftLiftAsDcMotor.setMode("RUN_TO_POSITION");
        rightLiftAsDcMotor.setMode("RUN_TO_POSITION");
        leftLiftAsDcMotor.setPower(0.65);
        rightLiftAsDcMotor.setPower(0.65);
      }
      telemetry.update();
    }
  }
}
