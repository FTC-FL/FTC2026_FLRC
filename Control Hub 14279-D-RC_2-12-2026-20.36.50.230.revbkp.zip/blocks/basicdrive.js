// IDENTIFIERS_USED=airplaneAsServo,gamepad1,gamepad2,imuAsIMU,intakebottomAsDcMotor,intaketopAsDcMotor,leftBackAsDcMotor,leftclawAsServo,leftcolorAsREVColorRangeSensor,leftFrontAsDcMotor,leftLiftAsDcMotor,rightBackAsDcMotor,rightclawAsServo,rightcolorAsREVColorRangeSensor,rightFrontAsDcMotor,rightLiftAsDcMotor,wristAsServo

var Angle, Turn, drive, GamepadDegree, power, Movement, Strafe, Forward, liftpower, liftamount, lastliftpos, clawOpen, manualintake, rightpixel, leftpixel, wristinpos, wristoutpos, FCdriving, intakeon, gp2back, pause, leftcolor, rightcolor;

/**
 * This function is executed when this OpMode is selected from the Driver Station.
 */
function runOpMode() {
  rightFrontAsDcMotor.setDirection("REVERSE");
  rightBackAsDcMotor.setDirection("REVERSE");
  leftLiftAsDcMotor.setDirection("REVERSE");
  leftLiftAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  rightLiftAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  intakebottomAsDcMotor.setDirection("REVERSE");
  intaketopAsDcMotor.setDirection("REVERSE");
  leftclawAsServo.setDirection("REVERSE");
  liftpower = 0.7;
  liftamount = 500;
  lastliftpos = 1500;
  clawOpen = false;
  manualintake = true;
  rightpixel = false;
  leftpixel = false;
  wristinpos = 0.42;
  wristoutpos = 0.49;
  FCdriving = true;
  intakeon = 'off';
  rightclawAsServo.setPosition(0.27);
  leftclawAsServo.setPosition(0.263);
  int_IMU();
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    wristAsServo.setPosition(0.415);
    while (linearOpMode.opModeIsActive()) {
      drive2();
      leftFrontAsDcMotor.setPower(Forward * Math.abs(Forward) + Strafe * Math.abs(Strafe) + Turn);
      rightFrontAsDcMotor.setPower((Forward * Math.abs(Forward) - Strafe * Math.abs(Strafe)) - Turn);
      rightBackAsDcMotor.setPower((Forward * Math.abs(Forward) + Strafe * Math.abs(Strafe)) - Turn);
      leftBackAsDcMotor.setPower((Forward * Math.abs(Forward) - Strafe * Math.abs(Strafe)) + Turn);
      if (gamepad1.getRightBumper() && intakeon == 'off') {
        intakeon = 'forward';
      } else if (gamepad1.getLeftBumper() && intakeon == 'off') {
        intakeon = 'reverse';
      } else if ((gamepad1.getRightBumper() || gamepad1.getLeftBumper()) && (intakeon == 'forward' || intakeon == 'reverse')) {
        intakeon = 'off';
      }
      if (leftpixel && rightpixel || leftLiftAsDcMotor.getCurrentPosition() >= 450) {
        intakeon = 'reverse';
      }
      if (intakeon == 'forward') {
        intakebottomAsDcMotor.setPower(0.9);
        intaketopAsDcMotor.setPower(0.9);
      } else if (intakeon == 'reverse') {
        intakebottomAsDcMotor.setPower(-0.75);
        intaketopAsDcMotor.setPower(-0.75);
      } else if (intakeon == 'off') {
        intakebottomAsDcMotor.setPower(0);
        intaketopAsDcMotor.setPower(0);
      }
      if (gamepad2.getDpadUp() && leftLiftAsDcMotor.getCurrentPosition() >= 100 && leftLiftAsDcMotor.getCurrentPosition() <= 2300) {
        leftLiftAsDcMotor.setTargetPosition(lastliftpos + liftamount);
        rightLiftAsDcMotor.setTargetPosition(lastliftpos + liftamount);
        leftLiftAsDcMotor.setMode("RUN_TO_POSITION");
        rightLiftAsDcMotor.setMode("RUN_TO_POSITION");
        leftLiftAsDcMotor.setDualPower(liftpower, rightLiftAsDcMotor, liftpower);
        lastliftpos = lastliftpos + liftamount;
        linearOpMode.sleep(100);
      }
      if (gamepad2.getDpadDown() && leftLiftAsDcMotor.getCurrentPosition() >= 1200 && leftLiftAsDcMotor.getCurrentPosition() <= 2800) {
        leftLiftAsDcMotor.setTargetPosition(lastliftpos - liftamount);
        rightLiftAsDcMotor.setTargetPosition(lastliftpos - liftamount);
        leftLiftAsDcMotor.setMode("RUN_TO_POSITION");
        rightLiftAsDcMotor.setMode("RUN_TO_POSITION");
        rightLiftAsDcMotor.setDualPower(liftpower, leftLiftAsDcMotor, liftpower);
        lastliftpos = lastliftpos - liftamount;
        linearOpMode.sleep(100);
      }
      if (gamepad2.getDpadUp() && leftLiftAsDcMotor.getCurrentPosition() <= 100) {
        gp2back = false;
        pause = elapsedTimeAccess.create();
        elapsedTimeAccess.reset(pause);
        leftclawAsServo.setPosition(0.18);
        rightclawAsServo.setPosition(0.18);
        leftLiftAsDcMotor.setTargetPosition(lastliftpos);
        rightLiftAsDcMotor.setTargetPosition(lastliftpos);
        leftLiftAsDcMotor.setMode("RUN_TO_POSITION");
        rightLiftAsDcMotor.setMode("RUN_TO_POSITION");
        rightLiftAsDcMotor.setDualPower(liftpower, leftLiftAsDcMotor, liftpower);
      }
      if (leftLiftAsDcMotor.getCurrentPosition() >= 450 && !gp2back) {
        wristAsServo.setPosition(wristoutpos);
      }
      if (gamepad2.getBack()) {
        gp2back = true;
        wristAsServo.setPosition(wristinpos);
        leftclawAsServo.setPosition(0.26);
        rightclawAsServo.setPosition(0.265);
        rightLiftAsDcMotor.setTargetPosition(0);
        leftLiftAsDcMotor.setTargetPosition(0);
        leftLiftAsDcMotor.setMode("RUN_TO_POSITION");
        rightLiftAsDcMotor.setMode("RUN_TO_POSITION");
        rightLiftAsDcMotor.setDualPower(liftpower, leftLiftAsDcMotor, liftpower);
        linearOpMode.sleep(100);
      }
      if (gamepad2.getDpadLeft()) {
        rightLiftAsDcMotor.setTargetPosition(1870);
        leftLiftAsDcMotor.setTargetPosition(1870);
        leftLiftAsDcMotor.setMode("RUN_TO_POSITION");
        rightLiftAsDcMotor.setMode("RUN_TO_POSITION");
        rightLiftAsDcMotor.setDualPower(liftpower, leftLiftAsDcMotor, liftpower);
        linearOpMode.sleep(100);
        lastliftpos = 1830;
      }
      if (gamepad2.getDpadRight()) {
        rightLiftAsDcMotor.setTargetPosition(700);
        leftLiftAsDcMotor.setTargetPosition(700);
        leftLiftAsDcMotor.setMode("RUN_TO_POSITION");
        rightLiftAsDcMotor.setMode("RUN_TO_POSITION");
        rightLiftAsDcMotor.setDualPower(liftpower, leftLiftAsDcMotor, liftpower);
        linearOpMode.sleep(100);
        lastliftpos = 1500;
      }
      leftcolor = leftcolorAsREVColorRangeSensor.getDistance("MM");
      rightcolor = rightcolorAsREVColorRangeSensor.getDistance("MM");
      if (rightcolor < 8) {
        rightpixel = true;
      } else {
        rightpixel = false;
      }
      if (leftcolor < 8) {
        leftpixel = true;
      } else {
        leftpixel = false;
      }
      if (rightpixel && leftLiftAsDcMotor.getCurrentPosition() < 450) {
        rightclawAsServo.setPosition(0.18);
      } else if (gamepad2.getB() && leftLiftAsDcMotor.getCurrentPosition() >= 450) {
        leftclawAsServo.setPosition(0.265);
      }
      if (leftpixel && leftLiftAsDcMotor.getCurrentPosition() < 450) {
        leftclawAsServo.setPosition(0.18);
      } else if (gamepad2.getX() && leftLiftAsDcMotor.getCurrentPosition() >= 450) {
        rightclawAsServo.setPosition(0.26);
      }
      if (gamepad1.getX()) {
        airplaneAsServo.setPosition(0.175);
      }
      if (gamepad1.getB()) {
        airplaneAsServo.setPosition(0);
      }
      if (rightpixel && leftpixel) {
        telemetry.addTextData('Pixels', String(2));
      } else if (rightpixel || leftpixel) {
        telemetry.addTextData('Pixels', String(1));
      } else {
        telemetry.addTextData('Pixels', String(0));
      }
      telemetry.addTextData('Current Lift Position', String(leftLiftAsDcMotor.getCurrentPosition()));
      telemetry.addTextData('claw pos', String(leftclawAsServo.getPosition()));
      telemetry.addTextData('wrist pos', String(wristAsServo.getPosition()));
      telemetry.addTextData('rtpos', String(gamepad2.getRightTrigger()));
      telemetry.update();
    }
  }
}

/**
 * Describe this function...
 */
function int_IMU() {
  // Initialize the IMU with non-default settings. To use this block, plug
  // one of the "new IMU.Parameters" blocks into the parameters socket.
  // Create a Parameters object for use with an IMU in a REV Robotics Control Hub or Expansion Hub, specifying the hub's orientation on the robot via the direction that the REV Robotics logo is facing and the direction that the USB ports are facing.
  imuAsIMU.initialize(imuParametersAccess.create(revHubOrientationOnRobotAccess.create1("RIGHT", "UP")));
}

/**
 * Describe this function...
 */
function GetZAxis() {
  Angle = imuAsIMU.getRobotOrientation("INTRINSIC", "ZYX", "DEGREES");
  return orientationAccess.getFirstAngle(Angle);
}

/**
 * Describe this function...
 */
function drive2() {
  Turn = gamepad1.getLeftStickX() * 0.5;
  drive = rangeAccess.clip(Math.sqrt(Math.pow(gamepad1.getRightStickX(), 2) + Math.pow(gamepad1.getRightStickY(), 2)), 0, 1);
  GamepadDegree = Math.atan2(-gamepad1.getRightStickY(), gamepad1.getRightStickX()) / Math.PI * 180;
  power = 0.6 + gamepad1.getRightTrigger() * 0.3;
  Movement = GamepadDegree - GetZAxis();
  Strafe = Math.cos(Movement / 180 * Math.PI) * drive * (power + 0.1);
  Forward = Math.sin(Movement / 180 * Math.PI) * drive * power;
}
