// IDENTIFIERS_USED=gamepad1,left_motor_frontAsDcMotor,right_motor_backAsDcMotor,right_motor_frontAsDcMotor

var vertical, horizontal, pivot;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  right_motor_frontAsDcMotor.setDirection("REVERSE");
  right_motor_backAsDcMotor.setDirection("REVERSE");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    vertical = -gamepad1.getLeftStickY();
    horizontal = gamepad1.getLeftStickX();
    pivot = gamepad1.getRightStickX();
    while (linearOpMode.opModeIsActive()) {
      right_motor_frontAsDcMotor.setPower(-pivot + (vertical - horizontal));
      right_motor_backAsDcMotor.setPower(-pivot + vertical + horizontal);
      left_motor_frontAsDcMotor.setPower(pivot + vertical + horizontal);
      left_motor_frontAsDcMotor.setPower(pivot + (vertical - horizontal));
      telemetry.update();
    }
  }
}
