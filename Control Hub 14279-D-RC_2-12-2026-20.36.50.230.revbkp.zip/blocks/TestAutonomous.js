// IDENTIFIERS_USED=motor1AsDcMotor

var mototarget, speed, motoPos, target;

/**
 * Describe this function...
 */
function drive(mototarget, speed) {
  motoPos = (typeof motoPos == 'number' ? motoPos : 0) + target;
  motor1AsDcMotor.setTargetPosition(mototarget);
  motor1AsDcMotor.setMode("RUN_TO_POSITION");
  motor1AsDcMotor.setPower(speed);
  while (linearOpMode.opModeIsActive() && motor1AsDcMotor.isBusy()) {
    linearOpMode.idle();
  }
}

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  motor1AsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  motoPos = 0;
  linearOpMode.waitForStart();
  drive(530, 0.25);
}
